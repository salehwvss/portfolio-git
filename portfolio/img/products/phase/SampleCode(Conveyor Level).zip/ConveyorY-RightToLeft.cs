﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConveyorYRightToLeft : MonoBehaviour {

    private ArrayList objects = new ArrayList();
    private Renderer rend;
    [SerializeField] private float velocityTexture = .1f; // this moves the texture of the platform
    [SerializeField] private Transform something;
    public static float velocityPlatform = .01f;  //this moves the platform holding the boxes
    private bool on = false;


    void Awake()
    {
        rend = something.GetComponent<Renderer>();

    }



    // Update is called once per frame
    void FixedUpdate()
    {
        rend.materials[0].SetTextureOffset("_MainTex", new Vector2(velocityTexture, 0) * Time.time); // this moves the texture of the platform
        Moving();
    }
    private void Moving()
    {
        foreach (Transform anObject in objects)
        {
            anObject.position += new Vector3(0, 0, velocityPlatform); //this moves the platform holding the boxes
        }


    }
    public void OnTriggerEnter(Collider collider)
    {
        objects.Add(collider.transform);
    }
    public void OnTriggerExit(Collider collider)
    {
        objects.Remove(collider.transform);
    }
}
