﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConveyorRednBoxSwitch : MonoBehaviour {


    private ArrayList objects = new ArrayList();
    private Renderer rend;
    [SerializeField] private float velocityTexture = -.1f; // this moves the texture of the platform
    [SerializeField] private Transform something;
    public static float velocityPlatform = .01f;  //this moves the platform holding the boxes
    public static bool on = false;       // if switch is not pressed
    public static bool platformRotate = false;

    
    public float turnSpeed = 0f;

    public bool changerotation = false;   //a boolean to switch between off rotation and on rotation

    AudioSource rotationSound;

    void Awake()
    {
        rend = something.GetComponent<Renderer>();

        rotationSound = GetComponent<AudioSource>();
        velocityPlatform = .01f;
        on = false;
        platformRotate = false;
        changerotation = false;
        turnSpeed = 180f;

    }

    void Setup()
    {
        velocityPlatform = .01f;
        on = false;
        platformRotate = false;
        changerotation = false;
        turnSpeed = 180f;
    }



    // Update is called once per frame
    void FixedUpdate()
    {
       // Debug.Log("platform rotate: " + platformRotate);

        if (on == false)
        { //if switch is not pressed
           // Debug.Log("on = false");
            Moving();
            rend.materials[0].SetTextureOffset("_MainTex", new Vector2(0, velocityTexture) * Time.time); // this moves the texture of the platform
            something.transform.Rotate(0, 0, 0);


            if (platformRotate == false && changerotation == true)
            {     // if platform is not movable and changerotation is true, then rotate the platform back to where it was
                turnSpeed = 90;
                something.transform.Rotate(Vector3.up, turnSpeed);
                platformRotate = true;
                rotationSound.Play();
            }

        }
        else if (on == true)
        {  //if switch is pressed
         //   Debug.Log("on = true");
            MovingDown();
            rend.materials[0].SetTextureOffset("_MainTex", new Vector2(0, velocityTexture) * Time.time); // this moves the texture of the platform



            if (platformRotate == true)
            {
                //something.transform.Rotate (0, 90, 0);
                turnSpeed = -90;
                something.transform.Rotate(Vector3.up, turnSpeed);
                platformRotate = false;
                changerotation = true;    // if the platform is rotatable, then set the changerotation to true is just for conveyor texture
                rotationSound.Play();
               // Debug.Log("You Pressed it once");
            }


        }
    }


    public void Moving()
    {
        foreach (Transform anObject in objects)
        {
            anObject.position += new Vector3(0, 0, velocityPlatform); //this moves the platform holding the boxes

        }


    }
    public void MovingDown()
    {
        foreach (Transform anObject in objects)
        {
            anObject.position += new Vector3(-velocityPlatform, 0, 0); //this moves the platform holding the boxes
        }


    }

    public void OnTriggerEnter(Collider collider)
    {
        objects.Add(collider.transform);
    }
    public void OnTriggerExit(Collider collider)
    {
        objects.Remove(collider.transform);
    }
}
