﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformMovements : MonoBehaviour {

    public float movespeed = -1;
    public Vector3 userDirection = Vector3.left;
    

    void Start () {
		
	}
	


	void Update () {

        transform.Translate(userDirection * movespeed * Time.deltaTime);

    }
}
