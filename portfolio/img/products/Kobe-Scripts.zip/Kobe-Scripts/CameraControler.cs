﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControler : MonoBehaviour {

	public playerController theplayer;
	private Vector3 lastplayerposition;
	private float distancetomove;

	// Use this for initialization
	void Start () {
		theplayer = FindObjectOfType<playerController>();
		lastplayerposition = theplayer.transform.position;
		
	}
	
	// Update is called once per frame
	void Update () {
		
		distancetomove = theplayer.transform.position.x - lastplayerposition.x;
		transform.position = new Vector3 (transform.position.x + distancetomove, transform.position.y, transform.position.z);

		lastplayerposition = theplayer.transform.position;

		
	}
}
