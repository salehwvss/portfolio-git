﻿using UnityEngine;
using System.Collections;

public class coinBehavior : MonoBehaviour {

	void OnTriggerEnter2D(Collider2D col){ 
		if (col.gameObject.tag == "pickup") { 
			Destroy (col.gameObject); 

		} 
	} 
}
