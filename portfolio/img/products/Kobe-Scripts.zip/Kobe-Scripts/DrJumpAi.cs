﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DrJumpAi : MonoBehaviour {

   

    public bool grounded = true;
    public float jumpPower = 300;
    private bool hasJumped = false;

    // Use this for initialization
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {

        if (!grounded && GetComponent<Rigidbody2D>().velocity.y == 0 && hasJumped == false)
        {
            grounded = true;
        }
      //  if (Input.GetKey(KeyCode.Space) && grounded == true)
     //   {
          //  hasJumped = true;
      //  }
    }

    void FixedUpdate()
    {
        if (hasJumped)
        {
            GetComponent<Rigidbody2D>().AddForce(transform.up * jumpPower);
            grounded = false;
            hasJumped = false;
        }
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "JumpPlatform")
        {
            hasJumped = true;
             Debug.Log("khord behesh");
            
        }
    }

}
