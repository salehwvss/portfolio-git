﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveGame : MonoBehaviour {
    
    public GameObject PlayerObject;
    public GameObject DrObject;

    void Start()
        {

        if (GameoverUI.gameover == true)
        {
           // GameoverUI.gameover = false;
            Vector3 savedPosition = new Vector3(-19.81f, 0, 0);
            PlayerObject.transform.position = savedPosition;

            Vector3 DrPosition = new Vector3(-27.5f, 0, 0);
            DrObject.transform.position = DrPosition;
            
        }

        if (StartButton2.savegameReset == true) // when savegameREset is true in startmenue, reset dr and kobe position
        {
            Vector3 savedPosition = new Vector3(-19.81f, 0, 0);
            PlayerObject.transform.position = savedPosition;

            Vector3 DrPosition = new Vector3(-27.5f, 0, 0);
            DrObject.transform.position = DrPosition;
           // GameoverUI.gameover = false;
            StartButton2.savegameReset = false;
        }
        else
        {
            
            Vector3 savedPosition = new Vector3(PlayerPrefs.GetFloat("playerX"), 0, 0);
            PlayerObject.transform.position = savedPosition;

            Vector3 DrPosition = new Vector3(PlayerPrefs.GetFloat("DrX"), PlayerPrefs.GetFloat("DrY"), PlayerPrefs.GetFloat("DrZ"));
            DrObject.transform.position = DrPosition;

        }
        }
        

        // Update is called once per frame
        void Update()
        {

      
        
        
            PlayerPrefs.SetFloat("playerX", PlayerObject.transform.position.x);
            PlayerPrefs.SetFloat("playerY", PlayerObject.transform.position.y);
            PlayerPrefs.SetFloat("playerZ", PlayerObject.transform.position.z);


        PlayerPrefs.SetFloat("DrX", DrObject.transform.position.x);
        PlayerPrefs.SetFloat("DrY", DrObject.transform.position.y);
        PlayerPrefs.SetFloat("DrZ", DrObject.transform.position.z);

    }

    public void returnMeBack()
    {
       
    }
        }


