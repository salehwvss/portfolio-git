﻿#pragma strict

function Start_Game_Button()
{
    Application.LoadLevel("Main");
}
