﻿using UnityEngine;
using System.Collections;

public class cameraFollow2dPlatformer : MonoBehaviour {

	public Transform target; //what camera is following
	public float smoothing; //damping effect
	Vector3 offset;        // the fixed distance between the camera and the character

	float lowY;    //maximum amount the camera will follow down the character
	// Use this for initialization
	void Start () {
		offset = transform.position - target.position;

		lowY = transform.position.y;
	}
	
	// Update is called once per frame
	void LateUpdate  () {
		Vector3 targetCamPos = target.position + offset;  // where the camera is located
		transform.position = Vector3.Lerp (transform.position, targetCamPos, 0.5f); // camera will move smoothly

		if (transform.position.y > lowY || transform.position.y < lowY) transform.position = new Vector3 (transform.position.x, 0, transform.position.z); // if camera goes off the screen, bring it back
		}

	}




