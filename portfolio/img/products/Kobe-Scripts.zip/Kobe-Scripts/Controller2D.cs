﻿internal class Controller2D
{
    internal object collisions;
}