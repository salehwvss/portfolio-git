﻿#pragma strict


var jellyValue = 5;

function OnTriggerEnter2D (info : Collider2D)
    {
	
        if(info.tag=="Player")
        {
            GameMaster.currentScore += jellyValue;
            Destroy(gameObject);
     
        }
        else if(info.tag=="dr")
        {


        }

        if(GameMaster.currentScore ==30){

            Debug.Log("30 ta Shod");
        }

    }
