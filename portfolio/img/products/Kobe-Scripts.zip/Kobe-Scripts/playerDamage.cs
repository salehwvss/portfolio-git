﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class playerDamage : MonoBehaviour
{
    public Image currentHealthbar;
    public Text ratioText;
    private float hitpoint = 3;
    private float maxHitpoint = 3;


    public int playerHealth = 3;
    int damage = 1;

    [SerializeField]
    private GameObject GameoverUI;
    public string scene;


    [Header("Visual components that make up the player ")]
    public SpriteRenderer[] sprites; // sprite for flickering
    static readonly float flickerTime = 0.1f; // flickr time
    public static bool speedDecrese=true;

    public AudioClip gotHitSound;

    public AudioClip BoostSound;

    public AudioClip gameoversound;

    public AudioClip BGSOUND;

    public Color loadToColor = Color.white;


    bool PlaySound = true; // to make bg sound false when kobe dies
    // Use this for initialization
    void Start()
    {
        GetComponent<AudioSource>().playOnAwake = false;  //for hisound
        GetComponent<AudioSource>().clip = gotHitSound; // for hisound
        GetComponent<AudioSource>().playOnAwake = false;  //for gameover sound
        GetComponent<AudioSource>().clip = gameoversound; // for gameover sound
        GetComponent<AudioSource>().playOnAwake = false;
        GetComponent<AudioSource>().clip = BoostSound;
        if (PlaySound)
        {
            GetComponent<AudioSource>().clip = BGSOUND;
        }
        GameObject Kobe = GameObject.Find("Kobe");
        playerController playerScript = Kobe.GetComponent<playerController>();
        UpdateHealthbar();
        print(playerHealth);
    }

    void FixedUpdate()
    {
        Update();


    }

    void Update()
    {
        if (this.GetComponent<SpriteRenderer>().material.color.r >= 0.01f)
        {
            this.GetComponent<SpriteRenderer>().material.color = Color.Lerp(this.GetComponent<SpriteRenderer>().material.color, Color.white, Time.deltaTime * 5f); 
            if(this.GetComponent<SpriteRenderer>().material.color.r < 0.01f)
            {
                this.GetComponent<SpriteRenderer>().material.color = Color.white;
            }
        }

       
    }

    //private void OnTriggerEnter2D(Collider2D collision)
    //{

    //}

     void OnCollisionEnter2D(Collision2D collision)
    {

        //----------------if obstacle hit player decrease speed
        if (collision.gameObject.tag == "obstacle" && CoinPickup.invincible == false )
        {
            // audiosource.Play();
            AudioSource.PlayClipAtPoint(gotHitSound, transform.position);


            //if(this.GetComponent<SpriteRenderer>().material.color.r == 1.0f)
            this.GetComponent<SpriteRenderer>().material.color = Color.red;
            //StartCoroutine(Flash());
            if ( speedDecrese == true) {       //reduce his speed on collision with obstacles only if speedDcrese is true
                playerController.maxSpeed -= damage;

            }
            Debug.Log("SPEED " + playerController.maxSpeed);
            collision.gameObject.GetComponent<BoxCollider2D>().enabled = false;
        }
        if (CoinPickup.boosting) // if kobe is boosting, do not decrese the speed when he hits obstacles
        {
            speedDecrese = false;
            AudioSource.PlayClipAtPoint(BoostSound, transform.position);


        }
        if (!CoinPickup.boosting) //if not in boost mode speedDcrease will be enabled again
        {
            speedDecrese = true;
        }

        if (playerController.maxSpeed <= 0 || collision.gameObject.tag == "Dr" && CoinPickup.invincible == false && !CoinPickup.boosting) // game over when dr colide with kobe
        {
            Destroy(gameObject);
            Initiate.Fade(scene, loadToColor, 0.7f); // load gameover  with fading

           // Application.LoadLevel(scene);
            GameoverUI.SetActive(true);
            

            AudioSource.PlayClipAtPoint(gameoversound, transform.position); // gameoversound

            PlaySound = false; // bg sound mutes when kobe dies
           

        }
       


        //---------------------------------------if player falls down gameover screen comes
            if (collision.gameObject.tag == "GameOverFloor")
        {
            Initiate.Fade(scene, loadToColor, 0.7f); // load gameover  with fading

          //  Application.LoadLevel(scene);

            GameoverUI.SetActive(true);
            
            StartCoroutine(Flash());
      }
    }


    private void UpdateHealthbar()
    {
        if (CoinPickup.invincible == false) {  // if player is not invinsible start losing health
        float ratio = hitpoint / maxHitpoint;
        currentHealthbar.rectTransform.localScale = new Vector3(ratio, 1, 1);
        ratioText.text = (ratio * 3).ToString("0");
        }
    }

    private void TakeDamage(float damage)
    {
        hitpoint -= damage;
        if (hitpoint < 0)
        {
            hitpoint = 0;
            Debug.Log("Dead!");

        }
        if (CoinPickup.invincible == false) // if player is not boosting, start updating healthbar if you got damage
        {
            UpdateHealthbar();
        }
    }
//------------------------------------method for flickering
    public IEnumerator Flash()
    {
        float time = 0f;
        bool showSprites = false;
        
        
            foreach (SpriteRenderer mr in sprites)
            {
                mr.enabled = showSprites;
            }
            yield return new WaitForSeconds(flickerTime);
            showSprites = !showSprites;
            time = time + flickerTime;
        
        foreach (SpriteRenderer mr in sprites)
        {
            mr.enabled = true;
        }
       
    }


}
