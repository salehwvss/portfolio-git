﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class grabberScript : MonoBehaviour {
    public bool grabbed;
    public RaycastHit2D hit;
    public float distance=2f;
    public Transform holdPoint;
    public float throwForce;

   // public Transform target;
    void Start () {
        
    }
	
	// Update is called once per frame
	void Update () {
        //if (Input.GetKeyDown(KeyCode.B))
       // {
            if (!grabbed)
            {
                Physics2D.queriesStartInColliders = false;
          //   hit =   Physics2D.Raycast(transform.position + new Vector3(2f, -4f, 0f), transform.position + new Vector3(5f, -4f, 0f) );

                if (hit.collider != null && hit.collider.tag=="Grabbable")
                {
                grabbed = true;
                }
            }
            //grab
            else 
            {
                grabbed = false;

                if(hit.collider.gameObject.GetComponent<Rigidbody2D>() != null)
                {
              //      hit.collider.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(transform.localScale.x, 0) * throwForce;
                }
            }
        //}
        if (grabbed)
            hit.collider.gameObject.transform.position = holdPoint.position;
       
	}

    private void OnDrawGizmos()
    {

    //    Gizmos.color = Color.green;
    //    Gizmos.DrawLine(transform.position + new Vector3(2f, -4f, 0f), transform.position + new Vector3(5f, -4f, 0f));
       // transform.position + new Vector3(0f, -4f, 0f), transform.forward* distance
    }
}
