﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ProjectineShooter : MonoBehaviour {
	
    public GameObject ProjectilePrefab;
    private List<GameObject> Projectiles = new List<GameObject>();
    private float ProjectileVelocity;
    public float throwForce;

    public string levelToLoad;

	Animator anim;
    public static bool check = false;

    Animator myAnim;
    private Collider2D mycollider;
    //  private int shootOnce = 0;

    float waitAnimation = 0; // this will start to count before going to next throw animation
    public bool WaitAnimationBool = false; // for throw animation

    private float fireRate = 5;
    void Start () {
        myAnim = GetComponent<Animator>();
        mycollider = GetComponent<Collider2D>();

        ProjectileVelocity = 3;
		anim = GetComponent<Animator>();
        
    }
	
	
	void Update () {
        //   if (Input.GetMouseButtonDown(0))
        //    {
        //       GameObject bullet = (GameObject)Instantiate(ProjectilePrefab, transform.position + new Vector3(2,0,0), Quaternion.identity);
        //       Projectiles.Add(bullet);

        // }

        for (int i = 0; i < Projectiles.Count; i++)
        {
            GameObject goBullet = Projectiles[i];
            if (goBullet != null)
            {
                goBullet.transform.Translate(new Vector3(10, -1) * Time.deltaTime * ProjectileVelocity);
                
            }
        }
        if (WaitAnimationBool)
        {
            waitAnimation++;
        }

    }

    

    // if (Input.GetMouseButtonDown(0))
    public void OnTriggerEnter2D(Collider2D collision)     // if collision happen

    {
       
        if (collision.gameObject.tag == "Grabbable")   // if dr collides with Jelly 1 shoot bullet
        {
            Destroy(collision.gameObject); //distroy the other jellies
            check = true; // if this is not true then he will not throw jelly after one time

            myAnim.runtimeAnimatorController = Resources.Load("Dr.Jelly-Throwing_1") as RuntimeAnimatorController; // dr jelly throw jelly when collide with jelly

            //myAnim.SetBool ("grabbed", true);
            WaitAnimationBool = true;           // when dr eat jelly this becomes true
            waitAnimation = 0;                  // each time dr eats jelly the timer gets to 0 and will start to add up in update
        }
        else
        {
            //   {
            if (waitAnimation >= 7)  // loads walking after some delay after he throws jelly
            {
                myAnim.runtimeAnimatorController = Resources.Load("Dr Jelly-Walking2_0") as RuntimeAnimatorController;
                //        myAnim.SetBool("grabbed", false);
                //  }
                
            }
        }
        if (collision.gameObject.tag == "Grabbable" && check == true)   // if dr collides with Jelly 1 shoot bullet
        {
            check = false;
            GameObject bullet = (GameObject)Instantiate(ProjectilePrefab, transform.position + new Vector3(2, 0, 0), Quaternion.identity);
            Projectiles.Add(bullet);
            //check = true;
            
        }

    
    }

    }
