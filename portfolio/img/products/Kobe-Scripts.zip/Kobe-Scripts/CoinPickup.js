﻿#pragma strict

var coinEffect : Transform;
public var coinValue = 1;

function OnTriggerEnter2D (info : Collider2D)
    {
	
        if(info.tag=="Player")
        {
            GameMaster.currentScore += coinValue;
     		Destroy(gameObject);
     
    }

    if(GameMaster.currentScore ==30){

    Debug.Log("30 ta Shod");
}

}
