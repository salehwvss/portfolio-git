﻿using UnityEngine;
using System.Collections;

public class needleBehavior : MonoBehaviour {
	int colNumber=0;
	//-------------------------------------------if player hits needle 3 times, it will die	
	void OnTriggerEnter2D(Collider2D col){ 
		if (col.gameObject.tag == "Player") { 
			colNumber += 1;
		} if (col.gameObject.tag == "Player" && colNumber==3){
			Destroy (col.gameObject); 
			}
		} 
	} 

