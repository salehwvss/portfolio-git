﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class CoinPickup : MonoBehaviour
{

    public Transform ParticleEffect; //particle effect

    public static int count;
    public static int jellyCount; // for jellies
    public Text CountText;
    public Text JellyText; // for jelly
    float SpeedingTimer = 0f;
    public float maxSpeedingTime = 1.5f;


    public float boostTime = 2.0f;
    public float currentBoostTime;
    public float boostDelayTime = 5.0f;
    public float currentBoostDelayTime;
    public static bool boosting = false;
    public float time;

    public float baseSpeed = 1.0f;
    public float speedBoost = 2.0f;
    public float speed;


    bool speeding;


    public Image BoostUI;
    public Image BoostUI2;
    public Image BubbleUI;

    public AudioClip candySound;


    //-------------invincible

    public SpriteRenderer[] sprites;
    static readonly float invincibilityTime = 2f;
    public static bool invincible = false;

    void Start()
    {
        if (KobeBossController.jellythrownbyKobe == true)
        {
            jellyCount = jellyCount - 1;

        }
        // count = 0;
        GetComponent<AudioSource>().playOnAwake = false;  //for candySound
        GetComponent<AudioSource>().clip = candySound; // for candySound

      //  count = PlayerPrefs.GetInt("CurrentScore"); //get score
       // jellyCount = PlayerPrefs.GetInt("Jellies"); // get jellies
                                                    //  count = 0;
                                                    //  jellyCount = 0;
        SetCountText();
        SetJellyCountText(); // call jelly function

        currentBoostTime = 0f;
        currentBoostDelayTime = 0f;
        //speed = baseSpeed;

        GameObject BoostImage = GameObject.Find("BoostUI"); //instance of boost image
        BoostUI = BoostImage.GetComponent<Image>();// get boost image
        BoostUI.enabled = false; //disable boost image on start
//------------------------------------------------------------------------------------------bubble image
        GameObject BubbleImage = GameObject.Find("BubbleUI"); //instance of boost image
        BubbleUI = BubbleImage.GetComponent<Image>();// get boost image
        BubbleUI.enabled = false; //disable boost image on start

    }

   
    // Use this for initialization
    private void OnCollisionEnter2D(Collision2D collision)
    {
        //----------for coins
     //   if (collision.gameObject.tag == "pickup")
       // {


         //   collision.gameObject.SetActive(false);

         //    Destroy(collision.gameObject);
      //      count = count + 1;
      //      SetCountText();
         //   PlayerPrefs.SetInt("CurrentScore", count); // save score and carry it


         //   AudioSource.PlayClipAtPoint(candySound, transform.position);


            
       //}
       if(collision.gameObject.tag == "CoinCount")
       {

            count = count + 1;
            SetCountText();
            if (PlayerPrefs.GetInt("CurrentScore") <count)
            {
                PlayerPrefs.SetInt("CurrentScore", count); // save score and carry it
            }
        //  collision.gameObject.GetComponent<CircleCollider2D>().enabled = false;
            collision.gameObject.GetComponent<BoxCollider2D>().enabled = false;
            Destroy(collision.gameObject);
       }

        //-----------for jelly
        if (collision.gameObject.tag == "Grabbable")
        {
            Transform effect = Instantiate(ParticleEffect, transform.position, transform.rotation) as Transform;
            Destroy(effect.gameObject, 0.33f); // remove effect after some second
            Destroy(collision.gameObject);
            count = count + 1;
            SetCountText();
          //  PlayerPrefs.SetInt("CurrentScore", count);  // save score and carry it

            //--------------------------count jellies
            jellyCount = jellyCount + 1;
            SetJellyCountText();
            if (PlayerPrefs.GetInt("Jellies") < jellyCount)
            {
                PlayerPrefs.SetInt("Jellies", jellyCount);  // save jelly and carry it

            }

        }



    }
    //-----------------------------------------for playing sound and removing coin and counting coin
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "pickup")
        {

        //     count = count + 1;
           //    SetCountText();
           //    PlayerPrefs.SetInt("CurrentScore", count);
            AudioSource.PlayClipAtPoint(candySound, transform.position);
            other.gameObject.GetComponent<BoxCollider2D>().enabled = false;
          //  Destroy(gameObject.collider2D);
            other.gameObject.GetComponent<SpriteRenderer>().enabled = false;
            Destroy(other.gameObject, candySound.length);// Destroy the object -after- the sound played
        }
    }

    public void Update()
    {
        SetCountText();
        SetJellyCountText();
        if ((count % 15 == 0) && !boosting && Time.time > currentBoostDelayTime && count != 0)
        {

            currentBoostTime = Time.time + boostTime; //start the timer for the boost
            boosting = true;
            playerController.maxSpeed = 15;
            BoostUI.enabled = true;
            BubbleUI.enabled = true;
            // StartCoroutine(Flash());
            invincible = true;

           

        }
       

        if ((Time.time > currentBoostTime) && boosting)
        { // am i boosting? has the boost timer expired?
            boosting = false;
            currentBoostDelayTime = Time.time + boostDelayTime;
            //speed = baseSpeed;
            playerController.maxSpeed = 13;
            BoostUI.enabled = false;
            BubbleUI.enabled = false;
            invincible = false;
            if (gameObject.CompareTag("BoostImg"))
            {

                gameObject.GetComponent<Renderer>().enabled = false;

            }
        }

    }



    public void  SetCountText()
    {
        CountText.text = "" + count.ToString(); //score
        
    }

    void SetJellyCountText()
    {
        JellyText.text = "" + jellyCount.ToString(); //jellies
    }
}
