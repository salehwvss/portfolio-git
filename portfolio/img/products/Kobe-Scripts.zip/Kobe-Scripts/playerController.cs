using UnityEngine;
using System.Collections;

public class playerController : MonoBehaviour {

    //movement variables
    [SerializeField]
    public static float maxSpeed=14f;
	Rigidbody2D myRB;
	Animator myAnim;

    public Vector3 userDirection = Vector3.right;


	// Use this for initialization
	void Start () {
		myRB = GetComponent<Rigidbody2D> ();
		myAnim = GetComponent<Animator> ();
	}
     void Update()
    {

    }

    void FixedUpdate() {
     
		myRB.velocity = new Vector2 (maxSpeed, myRB.velocity.y);
		myAnim.SetFloat ("Speed", maxSpeed);

		Debug.Log (maxSpeed);
	}
		
}
