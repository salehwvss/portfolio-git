﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Distance : MonoBehaviour {
     public GameObject Player; 


    public Transform leader;
    public float followSharpness = 0.1f;

    Vector3 _followOffset;

    void Start () {
          Player = GameObject.FindWithTag("Player");

        _followOffset = transform.position - leader.position;

    }
	


	void LateUpdate () {
         float dist = Vector2.Distance(Player.transform.position, transform.position); //get the distance between two objects
        print("Distance to other: " + dist);

        // Apply that offset to get a target position.
        Vector3 targetPosition = leader.position + _followOffset;

        // Keep our y position unchanged.
        targetPosition.y = transform.position.y;

        // Smooth follow.    
        transform.position += (targetPosition - transform.position) * followSharpness;
    }
}
