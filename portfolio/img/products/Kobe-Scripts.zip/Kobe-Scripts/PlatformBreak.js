﻿#pragma strict

function OnTriggerEnter2D (info : Collider2D)
    {
	
        if(info.tag=="Dr")
        {
            Destroy(gameObject);
     
        }
    }
