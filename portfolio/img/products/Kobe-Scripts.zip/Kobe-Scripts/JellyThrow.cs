﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JellyTrow : MonoBehaviour {
    public GameObject Bottle;
    Rigidbody2D rb;

     void Awake()
    {
        rb = Bottle.GetComponent<Rigidbody2D>();
    }

    public void ThrowObjectWithForce(float Power)
    {
        rb.AddForce(Vector3.forward * Power);
    }
}
