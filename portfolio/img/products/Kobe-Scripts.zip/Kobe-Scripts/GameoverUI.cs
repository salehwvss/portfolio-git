﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class GameoverUI : MonoBehaviour {
    public static bool gameover = false;
    private Vector3 initialPos;
    private Quaternion initialRotation;

    public void Quit()
    {
        Debug.Log("Application QUIT!");
        Application.Quit();
    }

    private void Start()
    {


                                                         //  initialPos = transform.position;
                                                         //  initialRotation = transform.rotation;
    }

    public void Retry()
    {

        gameover = true;

        SceneManager.LoadScene("StartMenu");
        //  transform.position = SaveGame.startPos;
       // transform.rotation = initialRotation;
       // transform.position = initialPos;
    //    PlayerPrefs.SetInt("CurrentScore", 0);
       // PlayerPrefs.SetInt("Jellies", 0);
        DrController.DrSpeed = 13;
        playerController.maxSpeed = 14;
		ProjectineShooter.check = true;

    }
    


}
