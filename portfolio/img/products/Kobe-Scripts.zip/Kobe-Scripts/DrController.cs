﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DrController : MonoBehaviour {

    //movement variables
    public static float DrSpeed = 13f;

    Rigidbody2D myRB;
    Animator myAnim;
    bool facingRight;

    //public static int movespeed = 2;
    public Vector3 userDirection = Vector3.right;


    // Use this for initialization
    void Start()
    {

        myRB = GetComponent<Rigidbody2D>();
        myAnim = GetComponent<Animator>();
     
    }

    void Update()
    {
        //   myAnim.runtimeAnimatorController = Resources.Load("dr meanlook walking_0") as RuntimeAnimatorController;
        
    }

    void FixedUpdate()
    {

		myRB.velocity = new Vector2(DrSpeed, myRB.velocity.y);
       // transform.position += Vector3.right * Time.deltaTime;
        myAnim.SetFloat("DrSpeeding", DrSpeed);
        print(DrSpeed);
    }



    void onCollisionEnter2D(Collider2D other)
    {
        if (other.transform.tag == "MovingPlatfrom")
        {
            transform.parent = other.transform;
        }
    }

}


