﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KobeJump : MonoBehaviour
{
    //private bool onGround;
    private float jumpPressure;
    private float minJump;
    private float maxJumpPressure;
    private Rigidbody2D rbody;
    bool jumping = false;
    //check if we are sliding
    public static bool sliding = false;
    float slideTimer = 0f;
    public float maxSlideTime = 1.5f;

    float jumpTimer = 0f;
    public float maxJumpTime = 1.5f;
    public Animator anim;

    // Use this for initialization
    void Start()
    {
        //onGround = true;
        jumpPressure = 0f;
        minJump = 6f;
        maxJumpPressure = 10f;
        rbody = GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update()
    {

        //if (onGround) {
        //-------------------------------slide
        if (Input.GetButtonDown("Slide") && !sliding)  //slide button(currenly left shift)
        {
            sliding = true;
            anim.SetBool("isSliding", true);
            slideTimer = 0f;
            gameObject.GetComponent<CapsuleCollider2D>().enabled = false;
            gameObject.GetComponent<BoxCollider2D>().enabled = false;
        }
        //------------------------for jump
        if (Input.GetMouseButton(0) && !jumping)  //slide button(currenly left shift)
        {
            anim.SetBool("isJumping", true);
            jumping = true;
            jumpTimer = 0f;

        }
        //-------------------------for slide
        if (sliding)
        {
            RobotController.jumpForce = 0; //   if you are sliding, you cannot jump with space
            // rbody.freezeRotation = false;
            slideTimer += Time.deltaTime;
            if (slideTimer > maxSlideTime)
            {

                anim.SetBool("isSliding", false);
                gameObject.GetComponent<CapsuleCollider2D>().enabled = true;
                gameObject.GetComponent<BoxCollider2D>().enabled = true;

                sliding = false;
            }
        }
        //-----------------------------restore the space jump
        if (!sliding)
        {
            RobotController.jumpForce = 550;
        }
        //---------------------for jump
        if (jumping)
        {

            // rbody.freezeRotation = false;
            jumpTimer += Time.deltaTime;
            if (jumpTimer > maxJumpTime)
            {

                anim.SetBool("isJumping", false);


                jumping = false;
            }
        }

	  

    }

    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("ground"))
        {
            //onGround = true;
        }
    }
    //-------------------------------this code will disable Kobe collider when he collide 
    //with jumpplatform in sabotage, so he falls and die
    public void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "JumpPlatform")
        {
            sliding = true; // need to be true so your jump wont work
            RobotController.jumpForce = 0f;  // jump force 0 when kobe colide with jumpplatform
            RobotController.grounded = false;
            RobotController.doubleJump = false;
            gameObject.GetComponent<CapsuleCollider2D>().enabled = false;
            gameObject.GetComponent<BoxCollider2D>().enabled = false;
            gameObject.GetComponent<CircleCollider2D>().enabled = false;
                   }

       else if (collision.gameObject.tag == "GameOverFloor")
        {
            sliding = false;
            RobotController.grounded = true;
            RobotController.doubleJump = true;
            gameObject.GetComponent<CapsuleCollider2D>().enabled = true;
            gameObject.GetComponent<BoxCollider2D>().enabled = true;
            gameObject.GetComponent<CircleCollider2D>().enabled = true;
        }
        }
}
