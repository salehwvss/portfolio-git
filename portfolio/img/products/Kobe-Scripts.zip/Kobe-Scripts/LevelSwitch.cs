﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class LevelSwitch : MonoBehaviour {

    public string levelToLoad;
    public int hitTime = 0;
    public int hit = 1;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Dr") // if jelly hits dr
        {
            hitTime = hitTime + hit;
            Destroy(gameObject);

        }
        else if (collision.tag == "Player" && hitTime>=1) //else if jelly hits player and hittime>=1
        {

            SceneManager.LoadScene(levelToLoad);
        }
    }

}
