﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RobotController : MonoBehaviour
{
    public static Rigidbody2D scriptRigidbody2D;
	public static Animator anim;

    public static bool grounded = false;
    public Transform groundCheck;
    float groundRadius = 0.2f;
    public LayerMask whatIsGround;
    public static float jumpForce = 100f;

    public static bool doubleJump = false;


    public AudioClip jumpsound;



    //moving to the right
    public Vector3 userDirection = Vector3.right;


	//slide
	bool jumping = false; //check if jumping
	public static bool sliding = false;
	public static float slideTimer = 0f;
	public static float maxSlideTime = 0.8f;


    // Use this for initialization
    void Start()
    {
      
        scriptRigidbody2D = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();

        GetComponent<AudioSource>().playOnAwake = false;  //for jumpsound
        GetComponent<AudioSource>().clip = jumpsound; // for jumpsound
    }

    // Update is called once per frame
    void FixedUpdate()
    {

        grounded = Physics2D.OverlapCircle(groundCheck.position, groundRadius, whatIsGround);
        anim.SetBool("Ground", grounded);

        anim.SetFloat("vSpeed", scriptRigidbody2D.velocity.y);

        if (grounded)
            doubleJump = false;
      
        anim.SetFloat("vSpeed", scriptRigidbody2D.velocity.y);
     
    }

    void Update()
    {
		///////////slide
		if (Input.GetButtonDown("Slide") && !sliding)  //slide button(currenly left shift)
		{
			sliding = true;
			anim.SetBool("isSliding", true);
			slideTimer = 0f;
			gameObject.GetComponent<CapsuleCollider2D>().enabled = false;
			gameObject.GetComponent<BoxCollider2D>().enabled = false;
		}

		if (sliding) 
		{
			jumpForce = 0; //   if you are sliding, you cannot jump 
			slideTimer += Time.deltaTime;

			if (slideTimer > maxSlideTime) 
			{
                sliding = false;
                anim.SetBool ("isSliding", false);
				gameObject.GetComponent<CapsuleCollider2D> ().enabled = true;
				gameObject.GetComponent<BoxCollider2D> ().enabled = true;

				
			}

		}
		///restore the jump 
		if (!sliding)
		{
			RobotController.jumpForce = 550;

        }

        if ((grounded || !doubleJump) && Input.GetKeyDown(KeyCode.Space))
        {
            anim.SetBool("Ground", false);
            scriptRigidbody2D.AddForce(new Vector2(1, jumpForce));
            AudioSource.PlayClipAtPoint(jumpsound, transform.position);

            if (!doubleJump && !grounded)
                doubleJump = true;
        }
 

	}
}