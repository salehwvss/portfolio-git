﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class boostImgVisibility : MonoBehaviour {
    SpriteRenderer rend;
	// Use this for initialization
	void Start () {
        rend = this.gameObject.GetComponent<SpriteRenderer>();
	}
	
	// Update is called once per frame
	void Update () {
        if (!CoinPickup.boosting) 
        {
            rend.enabled = false; //disable boost image if not boosting
        }
        else if (CoinPickup.boosting && !KobeJump.sliding)
        {
            rend.enabled = enabled; // enable boost image if boosting
        }
        if (KobeJump.sliding) // if you are sliding disable the boost image(otherwise it colides with player)
        {
            rend.enabled = false;
        }
	}
}
