﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CalculateDistance : MonoBehaviour {
	
    public Transform other;
    Animator myAnim;
	public float dist;

	private Collider2D mycollider;


    public AudioClip meanlooksound;


    // Use this for initialization
    void Start () {
        myAnim = GetComponent<Animator>();
		mycollider = GetComponent<Collider2D> ();

        GetComponent<AudioSource>().playOnAwake = false;  //for
        GetComponent<AudioSource>().clip = meanlooksound; // for 
    }

    // Update is called once per frame
    void Update () {
        Example();  // call function

    }


    void Example()
    {
        if (other)
        {
            dist = Vector3.Distance(other.position, transform.position); //distance between dr and Kobe
            Debug.Log("Distance to other: " + dist); // print distance between them
         

				//myAnim.runtimeAnimatorController = Resources.Load("dr meanlook walking_0") as RuntimeAnimatorController; // change dr jelly appearance to mean
                myAnim.SetFloat("distance", dist);


		 if (dist >= 16.5f)//mean look speed
			{
                AudioSource.PlayClipAtPoint(meanlooksound, transform.position);

                gameObject.GetComponent<Collider2D> ().offset = new Vector2 (0, 1);
				DrController.DrSpeed = 14.5f;

            }

            else if (dist < 12)
            {
				gameObject.GetComponent<Collider2D> ().offset = new Vector2 (0, 0);
				DrController.DrSpeed = 13f;
            }
        

        }
    }
}
